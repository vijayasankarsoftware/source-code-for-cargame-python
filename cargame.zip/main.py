from tkinter import *
from PIL import ImageTk, Image
import time
import random


class Car:
    def __init__(self,Game_Window, main):
        self.Game_Window = Game_Window
        self.main = main
        self.m = Image.open("images/car-top-view.png")
        self.l = self.m.rotate(90)
        self.n = ImageTk.PhotoImage(self.l)
        self.C_Car = self.Game_Window.create_image(50,50, anchor=NW, image=self.n)
        self.Game_Window.move(self.C_Car, 170,460)

        self.main.bind("<Right>", self.Right)
        self.main.bind("<Left>", self.Left)
        self.x = 125
        self.y = 0
    def Right(self,e):
        pos = self.Game_Window.coords(self.C_Car)
        if pos[0] >= 250:
            self.Game_Window.move(self.C_Car, 0,0)
        else:
            self.Game_Window.move(self.C_Car, self.x, self.y)


    def Left(self,e):
        pos = self.Game_Window.coords(self.C_Car)
        if pos[-2] <= 125:

            self.Game_Window.move(self.C_Car, 0,0)
        else:
            self.Game_Window.move(self.C_Car, -self.x,self.y)

class Opponent_Cars:
    def __init__(self, Game_Window, main, car, score, Title_Label, TrueOrFalse):
        self.Title_Label = Title_Label
        self.score = score
        self.Game_Window = Game_Window
        self.main = main
        self.car = car
        self.c_i_1 = Image.open("images/car-top-view (1).png").rotate(-90)
        self.c_i_1_n = ImageTk.PhotoImage(self.c_i_1)
        self.c_car_1 = self.Game_Window.create_image(10,10, image=self.c_i_1_n)
        self.c_car_2 = self.Game_Window.create_image(10,10, image=self.c_i_1_n)
        self.c_car_3 = self.Game_Window.create_image(10,10, image=self.c_i_1_n)
        self.Game_Window.move(self.c_car_1, 120, -100)
        self.Game_Window.move(self.c_car_2, 240, -300)
        self.Game_Window.move(self.c_car_3, 370, -500)
        self.x = 0
        self.y = 5
    def Game_Over(self):
        Game_Window.delete(ALL)
        Game_Window.create_text(250, 300, text="Game Over", font=("arial", 30), fill="red")
    def move(self):
        x = random.randrange(900, 1300)
        self.Game_Window.move(self.c_car_1, self.x, self.y)
        self.Game_Window.move(self.c_car_2, self.x, self.y)
        self.Game_Window.move(self.c_car_3, self.x, self.y)
        c_car_1_pos = self.Game_Window.coords(self.c_car_1)
        c_car_2_pos = self.Game_Window.coords(self.c_car_2)
        c_car_3_pos = self.Game_Window.coords(self.c_car_3)
        m_car = self.Game_Window.coords(self.car.C_Car)
        self.Title_Label.config(text="Score:       {}".format(self.score))
        try:
            if c_car_1_pos[1] >= 800:
                self.Game_Window.move(self.c_car_1, 0, -x)
            else:
                self.score += 1
            if c_car_2_pos[1] >= 800:
                self.Game_Window.move(self.c_car_2, 0, -x)
            else:
                self.score += 1
            if c_car_3_pos[1] >= 900:
                self.Game_Window.move(self.c_car_3, 0, -x)
            else:
                self.score += 1

            C_Car_Pos = self.Game_Window.coords(self.car.C_Car)

            # print(C_Car_Pos[0], "==", C_Car_Pos[1], "and", c_car_1_pos[0], "==", c_car_1_pos[1])

            if (c_car_1_pos[1] <= 570 and c_car_1_pos[1] >= 555 and C_Car_Pos[0] == 95):
                self.Game_Over()
            else:
                self.score += 1
            if (c_car_2_pos[1] <= 570 and c_car_2_pos[1] >= 555 and C_Car_Pos[0] == 220):
                self.Game_Over()
            else:
                self.score += 1
            if (c_car_3_pos[1] <= 570 and c_car_3_pos[1] >= 555 and C_Car_Pos[0] == 345):
                self.Game_Over()
            else:
                self.score += 1
        except IndexError:
            pass




main = Tk()
main.geometry("530x700")
main.resizable(False, False)
main.config(bg="green")
score = 0
Title_Label = Label(main, text="Car Race          Score :{}".format(score), width=500,font="arial 24 bold", bg="white")
Title_Label.pack()
Game_Window = Canvas(main, height=680, width=530, background="white")
Game_Window.pack()
b = Image.open("images/untitled.png")
bg = ImageTk.PhotoImage(b)
Game_Window.create_image(0,0, anchor=NW, image=bg)
TrueOrFalse = 1
car = Car(Game_Window, main)
op_cars = Opponent_Cars(Game_Window, main, car, score, Title_Label, TrueOrFalse)


while(TrueOrFalse == 1):
    main.update()
    main.update_idletasks()
    op_cars.move()
    time.sleep(0.01)